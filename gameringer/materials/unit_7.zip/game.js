var updates=0;
function update() {
}
function draw() {
};
function keyup(key) {
};
function mouseup() {
};